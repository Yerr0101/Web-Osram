<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "osram");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Tangani aksi tambah ke keranjang
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi'])) {
    $id_produk = (int)$_POST['id_produk'];
    $jumlah = (int)$_POST['jumlah'];
    
    // Dapatkan ID user dari session
    $username = $_SESSION['username'];
    $user_query = $conn->query("SELECT id_users FROM users WHERE username = '$username'");
    $user_data = $user_query->fetch_assoc();
    $id_users = $user_data['id_users'];
    
    // Dapatkan harga produk
    $produk_query = $conn->query("SELECT harga FROM produk WHERE id_produk = $id_produk");
    $produk_data = $produk_query->fetch_assoc();
    $harga = $produk_data['harga'];
    $total_harga = $harga * $jumlah;
    
    if ($_POST['aksi'] === 'keranjang') {
        // Cek apakah produk sudah ada di keranjang untuk user ini
        $cek = $conn->query("SELECT * FROM keranjang WHERE id_users = $id_users AND id_produk = $id_produk");
        if ($cek->num_rows > 0) {
            // Jika sudah ada, update jumlahnya dan total harga
            $conn->query("UPDATE keranjang SET jumlah = jumlah + $jumlah, total_harga = total_harga + $total_harga WHERE id_users = $id_users AND id_produk = $id_produk");
        } else {
            // Jika belum ada, masukkan record baru
            $conn->query("INSERT INTO keranjang (id_users, id_produk, jumlah, total_harga) VALUES ($id_users, $id_produk, $jumlah, $total_harga)");
        }
        
        header("Location: keranjang.php");
        exit();
} elseif ($_POST['aksi'] === 'beli') {
    // Tambahkan produk ke keranjang terlebih dahulu
    $cek = $conn->query("SELECT * FROM keranjang WHERE id_users = $id_users AND id_produk = $id_produk");
    if ($cek->num_rows > 0) {
        // Jika sudah ada, update jumlahnya dan total harga
        $conn->query("UPDATE keranjang SET jumlah = jumlah + $jumlah, total_harga = total_harga + $total_harga WHERE id_users = $id_users AND id_produk = $id_produk");
    } else {
        // Jika belum ada, masukkan record baru
        $conn->query("INSERT INTO keranjang (id_users, id_produk, jumlah, total_harga) VALUES ($id_users, $id_produk, $jumlah, $total_harga)");
    }

    header("Location: checkout.php");
    exit();
}
}

// Ambil ID produk dari URL (parameter: id_produk)
$id = isset($_GET['id_produk']) ? (int)$_GET['id_produk'] : 0;
$sql = "SELECT * FROM produk WHERE id_produk = $id";
$result = $conn->query($sql);
if ($result->num_rows == 0) {
    die("Produk tidak ditemukan.");
}
$produk = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Produk</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f2f2f2; }
        input[type=number]::-webkit-inner-spin-button, 
        input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
        input[type=number] { -moz-appearance: textfield; }
        header {
            position: sticky;
            top: 0;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #5F99AE;
            padding: 5px 20px;
            color: white;
            height: 60px;
        }
        .logo img { height: 50px; object-fit: contain; }
        nav ul {
            list-style: none;
            display: flex;
            gap: 15px;
        }
        nav ul li a {
            color: white;
            text-decoration: none;
            font-size: 14px;
            padding: 5px 10px;
            transition: 0.3s;
        }
        nav ul li a:hover {
            background: white;
            color: #5F99AE;
            border-radius: 5px;
        }
        .produk-page {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }
        footer {
            background: #5F99AE;
            color: white;
            text-align: center;
            padding: 10px;
            margin-top: 20px;
        }
        .btn-beli {
            background-color: #FFD700;
            color: #333;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .btn-beli:hover {
            background-color: #FFC300;
            transform: scale(1.05);
            box-shadow: 0 6px 10px rgba(0, 0, 0, 0.15);
        }
        .btn-tambah {
            background-color: white;
            color: black;
            border: 2px solid #FFD700;
            padding: 8px 14px;
            font-size: 14px;
            font-weight: bold;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .btn-tambah:hover {
            background-color: #FFD700;
            color: white;
            transform: scale(1.05);
            box-shadow: 0 6px 10px rgba(0, 0, 0, 0.15);
        }
    </style>
</head>
<body>

<header>
    <div class="logo">
        <img src="logo.png" alt="Logo OSRAM" />
    </div>
    <nav>
        <ul>
            <li><a href="index.php">Beranda</a></li>
            <li><a href="produk.php">Produk</a></li>
            <li><a href="promosi.php">Promosi</a></li>
            <li><a href="keranjang.php">🛒 <span style="font-size: 14px;">Keranjang</span></a></li>
            <li><a href="checkout.php">🛍️ <span style="font-size: 14px;">Checkout</span></a></li>
            <li><a href="logout.php">Logout (<?= htmlspecialchars($_SESSION['username']); ?>)</a></li>
        </ul>
    </nav>
</header>

<div class="produk-page">
    <h2>Detail Produk</h2>
    <img src="Produk/<?= file_exists('Produk/' . $produk['gambar']) ? $produk['gambar'] : 'default.png'; ?>" alt="<?= htmlspecialchars($produk['nama']) ?>" style="width: 100%; height: 300px; object-fit: contain;">
    <div style="text-align: center;">
        <h3><?= htmlspecialchars($produk['nama']) ?></h3>
        <p style="color: red; font-weight: bold;">Harga: Rp <?= number_format($produk['harga'], 0, ',', '.') ?></p>
        <form method="post" style="margin-bottom: 20px; display: flex; flex-direction: column; align-items: center;">
            <input type="hidden" name="id_produk" value="<?= $produk['id_produk'] ?>">
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                <label for="jumlah" style="font-weight: bold;">Jumlah:</label>
                <button type="button" onclick="ubahJumlah(-1)" style="padding: 6px 12px; font-size: 18px; background-color: #ddd; border: none; border-radius: 5px;">−</button>
                <input type="number" id="jumlah" name="jumlah" value="1" min="1" required style="width: 60px; padding: 6px; text-align: center; border: 1px solid #ccc; border-radius: 5px;">
                <button type="button" onclick="ubahJumlah(1)" style="padding: 6px 12px; font-size: 18px; background-color: #ddd; border: none; border-radius: 5px;">+</button>
            </div>
            <div style="display: flex; gap: 10px; flex-wrap: wrap; justify-content: center;">
                <button type="submit" name="aksi" value="beli" class="btn-beli">🛍️ Beli Sekarang!</button>
                <button type="submit" name="aksi" value="keranjang" class="btn-tambah">🛒 Tambah ke Keranjang</button>
            </div>
        </form>
        <p style="text-align: left;"><?= nl2br(htmlspecialchars($produk['deskripsi'])) ?></p>
    </div>
</div>

<footer>
    <p>&copy; 2025 OSRAM - Belanja Online Mudah & Cepat</p>
</footer>

<script>
    function ubahJumlah(delta) {
        var input = document.getElementById('jumlah');
        var current = parseInt(input.value);
        var newValue = current + delta;
        if (newValue >= 1) {
            input.value = newValue;
        }
    }
</script>

</body>
</html>