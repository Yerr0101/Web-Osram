<?php
session_start();
require 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $produk_terpilih = $_POST['produk'];
    $total = 0;

    foreach ($produk_terpilih as $id) {
        $data = mysqli_fetch_assoc(mysqli_query($conn, 
            "SELECT p.harga, k.jumlah 
             FROM keranjang k JOIN produk p ON k.produk_id = p.id 
             WHERE k.id = $id"));
        $total += $data['harga'] * $data['jumlah'];
    }
    ?>

    <div class="popup-checkout">
        <h3>Pembayaran</h3>
        <p>Total: Rp <?= number_format($total); ?></p>
        <form action="proses_pembayaran.php" method="POST">
            <input type="hidden" name="total" value="<?= $total; ?>">
            <label><input type="radio" name="metode" value="qris" required> QRIS</label><br>
            <label><input type="radio" name="metode" value="transfer"> Transfer</label><br>
            <label><input type="radio" name="metode" value="tunai"> Tunai</label><br><br>
            <button type="submit">Bayar</button>
        </form>
    </div>

    <style>
    .popup-checkout {
        position: fixed;
        top: 20%;
        left: 35%;
        background: white;
        padding: 20px;
        border: 1px solid #ccc;
        z-index: 1000;
    }
    </style>
<?php } ?>
