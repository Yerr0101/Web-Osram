<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Koneksi database
$conn = new mysqli("localhost", "root", "", "osram");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$username = $_SESSION['username'];
$user_query = $conn->query("SELECT id_users FROM users WHERE username = '$username'");
$user_data = $user_query->fetch_assoc();
$id_users = $user_data['id_users'];

// Ambil data keranjang user
$sql = "SELECT k.jumlah, k.total_harga, p.nama, p.harga 
        FROM keranjang k 
        JOIN produk p ON k.id_produk = p.id_produk
        WHERE k.id_users = $id_users";
$result = $conn->query($sql);
$total = 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Checkout</title>
  <style>
    /* Salin seluruh style dari keranjang.php */
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Arial, sans-serif; background: #f2f2f2; }
    header {
      position: sticky;
      top: 0;
      z-index: 1000;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #5F99AE;
      padding: 5px 20px;
      color: white;
      height: 60px;
    }
    .logo img { height: 50px; object-fit: contain; }
    nav ul {
      list-style: none;
      display: flex;
      gap: 15px;
    }
    nav ul li a {
      color: white;
      text-decoration: none;
      font-size: 14px;
      padding: 5px 10px;
      transition: 0.3s;
    }
    nav ul li a:hover {
      background: white;
      color: #5F99AE;
      border-radius: 5px;
    }
    .container {
      max-width: 800px;
      margin: 30px auto;
      background: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    h2 {
      margin-bottom: 20px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    th, td {
      padding: 10px;
      border-bottom: 1px solid #ddd;
      text-align: left;
    }
    th {
      background: #5F99AE;
      color: white;
    }
    .total {
      text-align: right;
      font-size: 18px;
      font-weight: bold;
    }
    .form-card {
  background: #ffffff;
  padding: 20px 25px;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(95, 153, 174, 0.2);
  max-width: 100%;
}

.form-card h3 {
  margin-bottom: 15px;
  color: #3b5e6b;
  font-weight: 700;
  font-size: 1.2rem;
  letter-spacing: 0.03em;
}

.payment-options {
  display: flex;
  gap: 15px;
  flex-wrap: wrap;
}

.radio-card {
  flex: 1 1 150px;
  background: #e6f2f7;
  border-radius: 10px;
  padding: 12px 15px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 10px;
  transition: background-color 0.3s ease;
  box-shadow: 0 2px 6px rgba(95, 153, 174, 0.15);
  user-select: none;
}

.radio-card input[type="radio"] {
  accent-color: #5F99AE;
  width: 18px;
  height: 18px;
  cursor: pointer;
}

.radio-card:hover {
  background-color: #c9e5f3;
  box-shadow: 0 4px 14px rgba(95, 153, 174, 0.3);
}

.radio-card input[type="radio"]:checked + span {
  font-weight: 700;
  color: #2f4c58;
}

textarea#alamat {
  width: 100%;
  padding: 12px 15px;
  border: 2px solid #5F99AE;
  border-radius: 10px;
  font-size: 1rem;
  resize: vertical;
  transition: border-color 0.3s ease;
}

textarea#alamat:focus {
  border-color: #3b5e6b;
  outline: none;
  box-shadow: 0 0 6px rgba(95, 153, 174, 0.6);
}

    .btn-confirm {
      background-color: #FFD700;
      text-decoration: none;
      color: #333;
      border: none;
      padding: 10px 20px;
      font-size: 16px;
      font-weight: bold;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.3s ease;
      margin-top: 20px;
      float: right;
    }
    .btn-confirm:hover {
      background-color: #FFC300;
      transform: scale(1.05);
      box-shadow: 0 6px 10px rgba(0, 0, 0, 0.15);
    }
    footer {
      background: #5F99AE;
      color: white;
      text-align: center;
      padding: 10px;
      margin-top: 40px;
    }
  </style>
</head>
<body>

<header>
  <div class="logo">
    <img src="logo.png" alt="Logo OSRAM" />
  </div>
  <nav>
    <ul>
      <li><a href="index.php">Beranda</a></li>
      <li><a href="produk.php">Produk</a></li>
      <li><a href="promosi.php">Promosi</a></li>
      <li><a href="keranjang.php">🛒 <span style="font-size: 14px;">Keranjang</span></a></li>
      <li><a href="checkout.php">🛍️ <span style="font-size: 14px;">Checkout</span></a></li>
      <li><a href="logout.php">Logout (<?= htmlspecialchars($_SESSION['username']); ?>)</a></li>
    </ul>
  </nav>
</header>

<div class="container">
  <h2>Konfirmasi Pesanan</h2>
  <?php if ($result->num_rows == 0): ?>
    <p>Keranjang kamu kosong, silakan belanja terlebih dahulu.</p>
    <a href="produk.php" class="btn-confirm">Belanja Sekarang</a>
  <?php else: ?>
    <table>
      <thead>
        <tr>
          <th>Produk</th>
          <th>Harga</th>
          <th>Jumlah</th>
          <th>Subtotal</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()):
          $subtotal = $row['harga'] * $row['jumlah'];
          $total += $subtotal;
        ?>
        <tr>
          <td><?= htmlspecialchars($row['nama']) ?></td>
          <td>Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
          <td><?= $row['jumlah'] ?></td>
          <td>Rp <?= number_format($subtotal, 0, ',', '.') ?></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
<p class="total">Total: Rp <?= number_format($total, 0, ',', '.') ?></p>

<form action="proses_checkout.php" method="POST" style="margin-top: 20px;">
  <div class="form-card">
    <h3>Metode Pembayaran</h3>
    <div class="payment-options">
      <label class="radio-card">
        <input type="radio" name="metode_pembayaran" value="COD" required>
        <span>COD (Bayar di Tempat)</span>
      </label>
      <label class="radio-card">
        <input type="radio" name="metode_pembayaran" value="Transfer">
        <span>Transfer Bank</span>
      </label>
      <label class="radio-card">
        <input type="radio" name="metode_pembayaran" value="QRIS">
        <span>QRIS</span>
      </label>
    </div>
  </div>

  <div class="form-card" style="margin-top: 20px;">
    <h3>Alamat Pengiriman</h3>
    <textarea name="alamat" id="alamat" rows="4" placeholder="Masukkan alamat lengkap Anda..." required></textarea>
  </div>

  <input type="hidden" name="total_harga" value="<?= $total ?>">
  <button type="submit" class="btn-confirm" style="margin-top: 20px;">Buat Pesanan</button>
</form>

  <?php endif; ?>
</div>

<footer>
  <p>&copy; <?= date('Y') ?> OSRAM. Semua Hak Dilindungi.</p>
</footer>

</body>
</html>
