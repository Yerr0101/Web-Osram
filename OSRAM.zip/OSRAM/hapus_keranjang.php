<?php
session_start();
require 'koneksi.php';

$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM keranjang WHERE id = $id");

header('Location: keranjang.php');
