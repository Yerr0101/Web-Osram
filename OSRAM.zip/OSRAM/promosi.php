<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Promosi - OSRAM</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background: #f2f2f2;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    header {
      position: sticky;
      top: 0;
      z-index: 1000;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #5F99AE;
      padding: 5px 20px;
      color: white;
      height: 60px;
    }

    .logo {
      position: relative;
      height: 50px;
    }

    .logo img {
      position: absolute;
      top: -30px;
      height: 100px;
      object-fit: contain;
    }

    nav ul {
      list-style: none;
      display: flex;
      gap: 15px;
    }

    nav ul li a {
      color: white;
      text-decoration: none;
      font-size: 14px;
      padding: 5px 10px;
      transition: 0.3s;
    }

    nav ul li a:hover {
      background: white;
      color: #5F99AE;
      border-radius: 5px;
    }

    .promo-page {
      flex: 1;
      padding: 30px 5%;
    }

    .promo-page h2 {
      font-size: 28px;
      margin-bottom: 10px;
    }

    .promo-page p {
      font-size: 16px;
      margin-bottom: 20px;
    }

    .promo-grid {
      display: flex;
      flex-direction: column;
      gap: 30px;
      align-items: center;
    }

    .promo-card {
      width: 1080px;
      height: 338px;
      overflow: hidden;
      border-radius: 16px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }

    .promo-card img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }

    footer {
      background: #5F99AE;
      color: white;
      text-align: center;
      padding: 12px;
      margin-top: 30px;
    }

    @media (max-width: 1100px) {
      .promo-card {
        width: 100%;
        height: auto;
        aspect-ratio: 1080 / 338;
      }
    }
  </style>
</head>
<body>

<header>
  <div class="logo">
    <img src="logo.png" alt="Logo OSRAM" />
  </div>
  <nav>
    <ul>
      <li><a href="index.php">Beranda</a></li>
      <li><a href="produk.php">Produk</a></li>
      <li><a href="promosi.php">Promosi</a></li>
      <li><a href="keranjang.php">🛒 <span style="font-size: 14px;">Keranjang</span></a></li>
      <li><a href="checkout.php">🛍️ <span style="font-size: 14px;">Checkout</span></a></li>
      <li><a href="logout.php">Logout (<?= htmlspecialchars($_SESSION['username']); ?>)</a></li>
    </ul>
  </nav>
</header>

<div class="promo-page">
  <h2>Promo Terbaru</h2>
  <p>Menampilkan <strong>4</strong> Gambar Promosi</p>

  <div class="promo-grid">
    <div class="promo-card">
      <img src="totole.png" alt="Promo 1">
    </div>
    <div class="promo-card">
      <img src="Kopi abc promo.png" alt="Promo 2">
    </div>
    <div class="promo-card">
      <img src="sunlight promo.png" alt="Promo 3">
    </div>
    <div class="promo-card">
      <img src="indomie promo.png" alt="Promo 4">
    </div>
  </div>
</div>

<footer>
  <p>&copy; 2025 OSRAM - Semua Produk Tersedia</p>
</footer>

</body>
</html>
