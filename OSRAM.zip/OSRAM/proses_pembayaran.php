<?php
session_start();
require 'koneksi.php';

$user_id = $_SESSION['user_id'];
$metode = $_POST['metode'];
$total = $_POST['total'];

// Simpan ke tabel transaksi atau cetak struk
mysqli_query($conn, "INSERT INTO transaksi (user_id, total, metode) VALUES ($user_id, $total, '$metode')");

// Kosongkan keranjang
mysqli_query($conn, "DELETE FROM keranjang WHERE user_id = $user_id");

echo "<script>alert('Pembayaran berhasil'); window.location='index.php';</script>";
