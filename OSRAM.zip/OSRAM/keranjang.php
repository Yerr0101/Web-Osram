<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "osram");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Dapatkan ID user dari session
$username = $_SESSION['username'];
$user_query = $conn->query("SELECT id_users FROM users WHERE username = '$username'");
$user_data = $user_query->fetch_assoc();
$id_users = $user_data['id_users'];

// Tangani aksi update keranjang
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['tambah'])) {
        $id_keranjang = (int)$_POST['id_keranjang'];
        // Dapatkan informasi harga produk
        $keranjang_query = $conn->query("SELECT k.id_produk, p.harga FROM keranjang k JOIN produk p ON k.id_produk = p.id_produk WHERE k.id_keranjang = $id_keranjang");
        $keranjang_data = $keranjang_query->fetch_assoc();
        $harga = $keranjang_data['harga'];
        
        $conn->query("UPDATE keranjang SET jumlah = jumlah + 1, total_harga = total_harga + $harga WHERE id_keranjang = $id_keranjang");
    }
    if (isset($_POST['kurang'])) {
        $id_keranjang = (int)$_POST['id_keranjang'];
        // Dapatkan informasi jumlah dan harga produk
        $keranjang_query = $conn->query("SELECT k.jumlah, p.harga FROM keranjang k JOIN produk p ON k.id_produk = p.id_produk WHERE k.id_keranjang = $id_keranjang");
        $keranjang_data = $keranjang_query->fetch_assoc();
        $jumlah = $keranjang_data['jumlah'];
        $harga = $keranjang_data['harga'];
        
        if ($jumlah > 1) {
            $conn->query("UPDATE keranjang SET jumlah = jumlah - 1, total_harga = total_harga - $harga WHERE id_keranjang = $id_keranjang");
        } else {
            $conn->query("DELETE FROM keranjang WHERE id_keranjang = $id_keranjang");
        }
    }
    if (isset($_POST['hapus'])) {
        $id_keranjang = (int)$_POST['id_keranjang'];
        $conn->query("DELETE FROM keranjang WHERE id_keranjang = $id_keranjang");
    }
    if (isset($_POST['checkout'])) {
        // Contoh checkout: mengosongkan keranjang pengguna tertentu
        $conn->query("DELETE FROM keranjang WHERE id_users = $id_users");
        echo "<script>alert('Checkout berhasil!');</script>";
    }
    
    // Redirect untuk mencegah pengiriman form ulang jika halaman direfresh
    header("Location: keranjang.php");
    exit();
}

// Ambil data keranjang dengan join ke tabel produk
$sql = "SELECT k.id_keranjang, k.id_produk, k.jumlah, k.total_harga, p.nama, p.harga, p.gambar 
        FROM keranjang k 
        JOIN produk p ON k.id_produk = p.id_produk
        WHERE k.id_users = $id_users";

$result = $conn->query($sql);
if (!$result) {
    die("Query error: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Keranjang Belanja</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Arial, sans-serif; background: #f2f2f2; }
    header {
      position: sticky;
      top: 0;
      z-index: 1000;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #5F99AE;
      padding: 5px 20px;
      color: white;
      height: 60px;
    }
    .logo img { height: 50px; object-fit: contain; }
    nav ul {
      list-style: none;
      display: flex;
      gap: 15px;
    }
    nav ul li a {
      color: white;
      text-decoration: none;
      font-size: 14px;
      padding: 5px 10px;
      transition: 0.3s;
    }
    nav ul li a:hover {
      background: white;
      color: #5F99AE;
      border-radius: 5px;
    }
    .container {
      max-width: 1000px;
      margin: 20px auto;
      background: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    table { width: 100%; border-collapse: collapse; }
    th, td {
      padding: 10px;
      text-align: center;
      border-bottom: 1px solid #ddd;
    }
    th { background-color: #5F99AE; color: white; }
    .btn-checkout {
      background-color: #FFD700;
      text-decoration: none;
      color: #333;
      border: none;
      padding: 10px 20px;
      font-size: 16px;
      font-weight: bold;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.3s ease;
      margin-top: 20px;
      float: right;
    }
    .btn-checkout:hover {
      background-color: #FFC300;
      transform: scale(1.05);
      box-shadow: 0 6px 10px rgba(0, 0, 0, 0.15);
    }
    footer {
      background: #5F99AE;
      color: white;
      text-align: center;
      padding: 10px;
      margin-top: 40px;
    }
    .kosong {
      text-align: center;
      padding: 50px;
      font-size: 18px;
      color: gray;
    }
    .action-buttons form {
      display: inline-block;
      margin: 0 2px;
    }
    .action-buttons button {
      padding: 5px 10px;
      border: none;
      background: #5F99AE;
      color: white;
      border-radius: 5px;
      cursor: pointer;
    }
    .action-buttons button:hover {
      background: #4a7c8e;
    }
    .product-image {
      width: 50px;
      height: 50px;
      object-fit: contain;
      margin-right: 10px;
      vertical-align: middle;
    }
    .product-name {
      display: flex;
      align-items: center;
      text-align: left;
    }
  </style>
</head>
<body>

<header>
  <div class="logo">
    <img src="logo.png" alt="Logo OSRAM" />
  </div>
  <nav>
    <ul>
      <li><a href="index.php">Beranda</a></li>
      <li><a href="produk.php">Produk</a></li>
      <li><a href="promosi.php">Promosi</a></li>
      <li><a href="keranjang.php">🛒 <span style="font-size: 14px;">Keranjang</span></a></li>
      <li><a href="checkout.php">🛍️ <span style="font-size: 14px;">Checkout</span></a></li>
      <li><a href="logout.php">Logout (<?= htmlspecialchars($_SESSION['username']); ?>)</a></li>
    </ul>
  </nav>
</header>

<div class="container">
  <h2>Keranjang Belanja</h2>
  <?php if ($result->num_rows == 0): ?>
    <p class="kosong">Keranjang kamu masih kosong 🛒</p>
    <p style="text-align: center; margin-top: 20px;">
      <a href="produk.php" style="display: inline-block; background: #5F99AE; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Belanja Sekarang</a>
    </p>
  <?php else: ?>
    <table>
      <thead>
        <tr>
          <th>Produk</th>
          <th>Harga Satuan</th>
          <th>Jumlah</th>
          <th>Subtotal</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php 
          $total = 0;
          while($row = $result->fetch_assoc()):
            $total += $row['total_harga'];
        ?>
          <tr>
            <td class="product-name">
              <img src="Produk/<?= file_exists('Produk/' . $row['gambar']) ? $row['gambar'] : 'default.png'; ?>" alt="<?= htmlspecialchars($row['nama']) ?>" class="product-image">
              <?= htmlspecialchars($row['nama']) ?>
            </td>
            <td>Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
            <td><?= $row['jumlah'] ?></td>
            <td>Rp <?= number_format($row['total_harga'], 0, ',', '.') ?></td>
            <td class="action-buttons">
              <form method="post" style="display:inline;">
                <input type="hidden" name="id_keranjang" value="<?= $row['id_keranjang'] ?>">
                <button type="submit" name="tambah">+</button>
              </form>
              <form method="post" style="display:inline;">
                <input type="hidden" name="id_keranjang" value="<?= $row['id_keranjang'] ?>">
                <button type="submit" name="kurang">−</button>
              </form>
              <form method="post" style="display:inline;">
                <input type="hidden" name="id_keranjang" value="<?= $row['id_keranjang'] ?>">
                <button type="submit" name="hapus">🗑️</button>
              </form>
            </td>
          </tr>
        <?php endwhile; ?>
        <tr>
          <th colspan="3">Total</th>
          <th colspan="2">Rp <?= number_format($total, 0, ',', '.') ?></th>
        </tr>
      </tbody>
    </table>
<a href="checkout.php" class="btn-checkout">🛍️ Checkout Sekarang</a>
  <?php endif; ?>
</div>

<footer>
  <p>&copy; 2025 OSRAM - Belanja Online Mudah & Cepat</p>
</footer>

</body>
</html>