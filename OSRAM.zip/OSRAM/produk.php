<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "osram");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Pagination
$limit = 12; // 12 produk per halaman
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Ambil data produk
$sql = "SELECT * FROM produk LIMIT $offset, $limit";
$result = $conn->query($sql);

// Hitung total produk
$total_produk = $conn->query("SELECT COUNT(*) as total FROM produk")->fetch_assoc()['total'];
$total_halaman = ceil($total_produk / $limit);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Produk - OSRAM</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
      font-family: Arial, sans-serif;
      background: #f2f2f2;
    }

    header {
      position: sticky;
      top: 0;
      z-index: 1000;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #5F99AE;
      padding: 5px 20px;
      color: white;
      height: 60px;
    }

    .logo img {
      height: 50px;
      object-fit: contain;
    }

    nav ul {
      list-style: none;
      display: flex;
      gap: 15px;
    }

    nav ul li a {
      color: white;
      text-decoration: none;
      font-size: 14px;
      padding: 5px 10px;
      transition: 0.3s;
    }

    nav ul li a:hover {
      background: white;
      color: #5F99AE;
      border-radius: 5px;
    }

    .produk-page {
      padding: 20px;
      max-width: 1200px;
      margin: 0 auto;
    }

    .produk-list {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 20px;
      margin-top: 20px;
    }

    .produk-list a.produk-card {
  width: 100%;
  height: 220px; /* Dulu 160px */
  display: block;
  background: white;
  border-radius: 10px;
  padding: 12px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.1);
  text-align: center;
  text-decoration: none;
  color: black;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.produk-list a.produk-card:hover {
  transform: scale(1.02);
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.produk-list .produk-card img {
  width: 100%;
  height: 120px; /* Dulu 90px */
  object-fit: contain;
  margin-bottom: 10px;
}

.produk-list .produk-card h3 {
  font-size: 15px; /* Dulu 13px */
  margin: 0;
  margin-bottom: 6px;
}

.produk-list .produk-card p {
  font-size: 14px; /* Dulu 12px */
  color: red;
  font-weight: bold;
  margin: 0;
}

    .pagination {
      text-align: center;
      margin-top: 30px;
    }

    .pagination a {
      color: #5F99AE;
      padding: 8px 16px;
      text-decoration: none;
      margin: 0 5px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    .pagination a:hover {
      background-color: #5F99AE;
      color: white;
    }

    .pagination a.active {
      background-color: #5F99AE;
      color: white;
      border: 1px solid #5F99AE;
    }

    footer {
      background: #5F99AE;
      color: white;
      text-align: center;
      padding: 10px;
      margin-top: 20px;
    }
  </style>
</head>
<body>

<header>
  <div class="logo">
    <img src="logo.png" alt="Logo OSRAM" />
  </div>
  <nav>
    <ul>
      <li><a href="index.php">Beranda</a></li>
      <li><a href="produk.php">Produk</a></li>
      <li><a href="promosi.php">Promosi</a></li>
      <li><a href="keranjang.php">🛒 <span style="font-size: 14px;">Keranjang</span></a></li>
      <li><a href="checkout.php">🛍️ <span style="font-size: 14px;">Checkout</span></a></li>
      <li><a href="logout.php">Logout (<?= htmlspecialchars($_SESSION['username']); ?>)</a></li>
    </ul>
  </nav>
</header>

<div class="produk-page">
  <h2>Semua Produk</h2>
  <div class="produk-list">
  <?php while ($row = $result->fetch_assoc()): ?>
    <?php
      $gambar = 'Produk/' . $row['gambar'];
      $gambar_src = file_exists($gambar) ? $gambar : 'Produk/default.png';
    ?>
    <a href="detail_produk.php?id_produk=<?= $row['id_produk'] ?>" class="produk-card">
      <img src="<?= $gambar_src ?>" alt="<?= htmlspecialchars($row['nama']) ?>" />
      <h3><?= htmlspecialchars($row['nama']) ?></h3>
      <p>Rp <?= number_format($row['harga'], 0, ',', '.') ?></p>
    </a>
  <?php endwhile; ?>
</div>

  <!-- Pagination -->
  <div class="pagination">
    <?php if ($page > 1): ?>
      <a href="?page=<?= $page - 1 ?>">&laquo;</a>
    <?php endif; ?>
    
    <?php for ($i = 1; $i <= $total_halaman; $i++): ?>
      <a href="?page=<?= $i ?>" class="<?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
    <?php endfor; ?>

    <?php if ($page < $total_halaman): ?>
      <a href="?page=<?= $page + 1 ?>">&raquo;</a>
    <?php endif; ?>
  </div>
</div>


<footer>
  <p>&copy; 2025 OSRAM - Belanja Online Mudah & Cepat</p>
</footer>

</body>
</html>