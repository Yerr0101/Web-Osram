<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>OSRAM - Belanja Online Mudah</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>

  
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: Arial, sans-serif;
      background: #f2f2f2;
    }
    header {
      position: sticky;
      top: 0;
      z-index: 1000;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #5F99AE;
      padding: 5px 20px;
      color: white;
      height: 60px;
    }
    .logo {
      position: relative;
      height: 50px;
    }
    .logo img {
      position: absolute;
      top: -30px;
      height: 100px;
      object-fit: contain;
    }
    nav ul {
      list-style: none;
      display: flex;
      gap: 15px;
    }
    nav ul li a {
      color: white;
      text-decoration: none;
      font-size: 14px;
      padding: 5px 10px;
      transition: 0.3s;
    }
    nav ul li a:hover {
      background: white;
      color: #5F99AE;
      border-radius: 5px;
    }
    .carousel-container {
      max-width: 1080px;
      height: 338px;
      margin: 20px auto;
      border-radius: 10px;
      overflow: hidden;
      position: relative;
    }
    .swiper {
      width: 100%;
      height: 100%;
    }
    .swiper-slide img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .categories, .products {
      padding: 20px;
      background: white;
      margin: 20px auto;
      border-radius: 10px;
      max-width: 1200px;
    }
    .category-list {
      display: flex;
      gap: 15px;
      flex-wrap: wrap;
      justify-content: center;
    }
    .category {
      flex: 1 1 200px;
      text-align: center;
      background: #f9f9f9;
      border: 1px solid #ddd;
      border-radius: 10px;
      padding: 10px;
      transition: 0.3s;
    }
    .category:hover {
      background: #e0e0e0;
    }
    .category img {
      width: 100px;
      height: 100px;
      object-fit: cover;
      margin-bottom: 10px;
    }

    /* Produk Carousel */
    .produk-swiper .swiper-slide {
      background: white;
      border: 1px solid #ddd;
      border-radius: 10px;
      padding: 10px;
      text-align: center;
    }
    .produk-swiper .product img {
      width: 100px;
      height: 100px;
      object-fit: cover;
      margin-bottom: 10px;
    }
    .produk-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 15px;
    }
    .produk-header a {
      color: #5F99AE;
      font-size: 14px;
      text-decoration: none;
      transition: 0.3s;
    }
    .produk-header a:hover {
      text-decoration: underline;
    }
    footer {
      background: #5F99AE;
      color: white;
      text-align: center;
      padding: 10px;
      margin-top: 20px;
    }
  </style>
</head>
<body>

<header>
  <div class="logo">
    <img src="logo.png" alt="Logo OSRAM" />
  </div>
  <nav>
    <ul>
      <li><a href="#">Beranda</a></li>
      <li><a href="produk.php">Produk</a></li>
      <li><a href="promosi.php">Promosi</a></li>
      <li><a href="keranjang.php">🛒 <span style="font-size: 14px;">Keranjang</span></a></li>
      <li><a href="checkout.php">🛍️ <span style="font-size: 14px;">Checkout</span></a></li>
      <li><a href="logout.php">Logout (<?= htmlspecialchars($_SESSION['username']); ?>)</a></li>
    </ul>
  </nav>
</header>

<!-- ✅ Carousel Banner -->
<div class="carousel-container">
  <div class="swiper">
    <div class="swiper-wrapper">
      <div class="swiper-slide"><img src="banner4.png" alt="Banner 1"></div>
      <div class="swiper-slide"><img src="banner2.png" alt="Banner 2"></div>
      <div class="swiper-slide"><img src="banner3.png" alt="Banner 3"></div>
    </div>
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
    <div class="swiper-pagination"></div>
  </div>
</div>

<!-- ✅ Kategori Produk -->
<section class="categories">
  <h2>Kategori Produk</h2>
  <div class="category-list">
    <div class="category"><img src="kuekaleng.jpg" alt="Makanan"><p>Makanan</p></div>
    <div class="category"><img src="minuman.jpg" alt="Minuman"><p>Minuman</p></div>
    <div class="category"><img src="kesehatan.jpg" alt="Kesehatan"><p>Kesehatan</p></div>
    <div class="category"><img src="peralatan.png" alt="Peralatan"><p>Peralatan</p></div>
  </div>
</section>

<!-- ✅ Produk Unggulan -->
<section class="products">
  <div class="produk-header">
    <h2>Produk Unggulan</h2>
    <a href="produk.php">Lihat Semua</a>
  </div>
  <div class="swiper produk-swiper">
    <div class="swiper-wrapper">
      <div class="swiper-slide product"><img src="Produk/telur 33k.png" alt="Produk 1"><p>Telur</p><span>Rp 33.000</span></div>
      <div class="swiper-slide product"><img src="Produk/golda 3k.png" alt="Produk 2"><p>Kopi Golda</p><span>Rp 3.000</span></div>
      <div class="swiper-slide product"><img src="Produk/Qtela 18k.png" alt="Produk 3"><p>Qtela</p><span>Rp 5.000</span></div>
      <div class="swiper-slide product"><img src="Produk/milo 11k.png" alt="Produk 4"><p>Snack Milo</p><span>Rp 11.000</span></div>
      <div class="swiper-slide product"><img src="Produk/beras sania 76k.png" alt="Produk 5"><p>Beras Sania</p><span>Rp 76.000</span></div>
      <div class="swiper-slide product"><img src="Produk/bimoli 33k.png" alt="Produk 6"><p>Minyak Bimoli</p><span>Rp 33.000</span></div>
      <div class="swiper-slide product"><img src="Produk/lifebuoy batang 5k.png" alt="Produk 7"><p>Sabun Mandi</p><span>Rp 5.000</span></div>
      <div class="swiper-slide product"><img src="Produk/pensil 16k.png" alt="Produk 8"><p>Teh Celup</p><span>Rp 16.000</span></div>
      <div class="swiper-slide product"><img src="Produk/rokok la ice 34k.png" alt="Produk 9"><p>Kopi Sachet</p><span>Rp 34.000</span></div>
      <div class="swiper-slide product"><img src="Produk/tissue nice 42k.png" alt="Produk 10"><p>Coklat Bar</p><span>Rp 42.000</span></div>
    </div>
    <!-- Tombol Navigasi -->
    <div class="swiper-button-next produk-next"></div>
    <div class="swiper-button-prev produk-prev"></div>
  </div>
</section>


<footer>
  <p>&copy; 2025 OSRAM - Belanja Online Mudah & Cepat</p>
</footer>

<!-- ✅ SwiperJS -->
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script>
const swiper = new Swiper(".swiper", {
  loop: true,

  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev"
  },
  pagination: {
    el: ".swiper-pagination",
    clickable: true
  }
});

  const produkSwiper = new Swiper(".produk-swiper", {
    slidesPerView: 2,
    spaceBetween: 15,
    navigation: {
      nextEl: ".produk-next",
      prevEl: ".produk-prev"
    },
    breakpoints: {
      640: { slidesPerView: 2 },
      768: { slidesPerView: 3 },
      1024: { slidesPerView: 4 },
      1200: { slidesPerView: 6 }
    }
  });
</script>

</body>
</html>
