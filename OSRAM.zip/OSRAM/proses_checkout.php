<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Koneksi database
$conn = new mysqli("localhost", "root", "", "osram");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$username = $_SESSION['username'];
$user_query = $conn->query("SELECT id_users FROM users WHERE username = '$username'");
$user_data = $user_query->fetch_assoc();
$id_users = $user_data['id_users'];

// Ambil data dari form
$metode_pembayaran = $_POST['metode_pembayaran'];
$alamat = $conn->real_escape_string($_POST['alamat']);
$total_harga = $_POST['total_harga'];

// Simpan ke tabel pesanan
$tanggal = date("Y-m-d H:i:s");
$conn->query("INSERT INTO pesanan (id_users, tanggal_pesanan, total_harga, metode_pembayaran, alamat)
              VALUES ($id_users, '$tanggal', $total_harga, '$metode_pembayaran', '$alamat')");

$id_pesanan = $conn->insert_id;

// Ambil data dari keranjang
$sql = "SELECT * FROM keranjang WHERE id_users = $id_users";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    $id_produk = $row['id_produk'];
    $jumlah = $row['jumlah'];
    $harga = $row['total_harga'] / $jumlah;

    $conn->query("INSERT INTO detail_pesanan (id_pesanan, id_produk, jumlah, harga)
                  VALUES ($id_pesanan, $id_produk, $jumlah, $harga)");
}

// Kosongkan keranjang
$conn->query("DELETE FROM keranjang WHERE id_users = $id_users");

// Redirect ke halaman sukses
header("Location: checkout_success.php");
exit();
?>
