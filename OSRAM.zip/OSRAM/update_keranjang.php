<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $action = $_POST['action'];

    if (isset($_SESSION['keranjang'][$id])) {
        if ($action === 'plus') {
            $_SESSION['keranjang'][$id]++;
        } elseif ($action === 'minus') {
            $_SESSION['keranjang'][$id]--;
            if ($_SESSION['keranjang'][$id] <= 0) {
                unset($_SESSION['keranjang'][$id]);
            }
        } elseif ($action === 'remove') {
            unset($_SESSION['keranjang'][$id]);
        }
    }

    header("Location: keranjang.php");
    exit();
}
?>
