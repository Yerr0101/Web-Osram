<?php
include 'config.php';

$username = $_POST['username'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$nama     = $_POST['nama'];

$sql = "INSERT INTO users (username, password, nama) VALUES ('$username', '$password', '$nama')";
if (mysqli_query($conn, $sql)) {
    echo "Pendaftaran berhasil. <a href='login.php'>Login Sekarang</a>";
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
