<?php
session_start();
require 'koneksi.php';

$id = $_GET['id'];
$act = $_GET['act'];

if ($act == 'plus') {
    mysqli_query($conn, "UPDATE keranjang SET jumlah = jumlah + 1 WHERE id = $id");
} elseif ($act == 'minus') {
    $cek = mysqli_fetch_assoc(mysqli_query($conn, "SELECT jumlah FROM keranjang WHERE id = $id"));
    if ($cek['jumlah'] > 1) {
        mysqli_query($conn, "UPDATE keranjang SET jumlah = jumlah - 1 WHERE id = $id");
    } else {
        mysqli_query($conn, "DELETE FROM keranjang WHERE id = $id");
    }
}

header('Location: keranjang.php');
